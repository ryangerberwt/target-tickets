try {
    if (!p_Market)
        return undefined;

    if (p_Info != -1)
        user.setLocal(p_Market + '-Vehicle-Info-V3', p_Info);
    
    return user.getLocal(p_Market + '-Vehicle-Info-V3');
} catch (e) {
    return undefined;
}